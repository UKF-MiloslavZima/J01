package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        TextField tf = new TextField();
        Button btn = new Button("OK");
        Label l = new Label();
        VBox root = new VBox();
        Scene scene = new Scene(root,300,300);
        root.getChildren().addAll(tf,btn,l);
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String text = tf.getText();
                l.setText(text);
                int dlzka = text.length();
                int pocetsamo = 0;
                int pocetspolu = 0;
                for(int i = 0 ; i < dlzka;i++){
                    if(text.charAt(i)=='a'|text.charAt(i)=='e'|text.charAt(i)=='i'|text.charAt(i)=='o'|text.charAt(i)=='u'|text.charAt(i)=='y'){
                        pocetsamo++;
                    } else pocetspolu++;
                }
                int r = pocetsamo * 16;
                int g = pocetspolu *24;
                int b = (dlzka % 25)*10;
                Color c = Color.rgb(r,g,b);
                scene.setFill(c);

            }
        });



        primaryStage.setTitle("Textový vstup");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
